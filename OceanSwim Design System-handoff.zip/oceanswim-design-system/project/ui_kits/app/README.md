# OceanSwim app — UI kit

A click-thru recreation of the OceanSwim mobile-first app. Drop the JSX
components into any prototype to get pixel-faithful Salidas / Tracking /
Rutas surfaces with the brand teal gradient, signature tinted shadows,
and Spanish copy intact.

## Files

- `index.html` — entry; loads React 18 UMD + Babel + the three JSX files
- `styles.css` — extracted from `oceanswim/src/styles/tailwind.css` plus a
  small phone-frame wrapper (`.phone-frame`)
- `components.jsx` — primitives: `AppHeader`, `TabBar`, `Field`, `Card`,
  `Button`, `Phone`, Feather icons (`IconUsers/Activity/Map`), constants
  (`ORGANIZERS`, `LOCATIONS`, `SEED_SALIDAS`, `SEED_RUTAS`), formatters
- `screens.jsx` — `SalidasList`, `SalidaForm`, `TrackingSelector`,
  `TrackingForm`, `TrackingTimer`, `RutasList`, `RutaDetail`
- `App.jsx` — wires the tabs together as an interactive demo

## Click-thru flow

1. **Salidas** — list of planned swims; tap *+ Nueva Salida* to open the
   form, fill it (organizer / date / distance / beach / participants) and
   submit; the new card joins the list. Edit/delete also work.
2. **Tracking** — pick a pending salida → enter completed km → success
   toast → the salida moves out of *pending* and a new *Ruta* is appended.
   A free-form stopwatch is also exposed below the selector.
3. **Rutas** — list of saved routes; tap one for the detail screen with
   the GPS-fallback message *"No hay datos de GPS para mostrar en el
   mapa"* (intentional — the demo doesn't carry coordinate data).

## What's intentionally simplified

- No `localStorage` persistence — state is in-memory React state.
- No real Leaflet map; the GPS fallback panel is shown in `RutaDetail`.
- No surf-forecast iframe modal (out of scope for a UI mock).
- Date validation skipped (the codebase enforces "future date only" for
  new salidas; the demo accepts whatever you type).

## Reuse

```jsx
<Phone>
  <AppHeader />
  <div className="scroll">…your screen…</div>
  <TabBar active="salidas" onChange={setTab} />
</Phone>
```

Use `Card`, `Button variant="primary|secondary|danger"`, and `Field` for
anything else — they encode the brand styling correctly.
