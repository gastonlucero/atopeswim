/* OceanSwim — interactive click-thru app demo */
const { useState: useS } = React;

function App() {
  const [tab, setTab]           = useS('salidas');
  const [salidas, setSalidas]   = useS(SEED_SALIDAS);
  const [rutas, setRutas]       = useS(SEED_RUTAS);
  const [editingS, setEditingS] = useS(null);
  const [formOpen, setFormOpen] = useS(false);
  const [trackingSel, setTrackingSel] = useS(null);
  const [selectedR, setSelectedR]     = useS(null);

  const saveS = (s) => {
    setSalidas(prev => editingS ? prev.map(x => x.id === s.id ? s : x) : [...prev, s]);
    setFormOpen(false); setEditingS(null);
  };
  const deleteS = (id) => setSalidas(prev => prev.filter(x => x.id !== id));
  const finishTracking = (s, km) => {
    setSalidas(prev => prev.map(x => x.id === s.id ? { ...x, status: 'finished' } : x));
    setRutas(prev => [{
      id: 'r' + Date.now(),
      name: `${s.organizerName} - ${s.location.description}`,
      salidaDate: s.dateTime,
      distanceKm: km,
    }, ...prev]);
    setTrackingSel(null);
  };

  let body;
  if (tab === 'salidas') {
    body = formOpen
      ? <SalidaForm editing={editingS} onSave={saveS} onCancel={() => { setFormOpen(false); setEditingS(null); }} />
      : <SalidasList salidas={salidas} onNew={() => { setEditingS(null); setFormOpen(true); }} onEdit={s => { setEditingS(s); setFormOpen(true); }} onDelete={deleteS} />;
  } else if (tab === 'tracking') {
    if (trackingSel) body = <TrackingForm salida={trackingSel} onFinish={finishTracking} onBack={() => setTrackingSel(null)} />;
    else body = <>
      <TrackingSelector pending={salidas.filter(s => s.status === 'pending')} onSelect={setTrackingSel} />
      <div style={{ marginTop: 24, paddingTop: 16, borderTop: '1px dashed rgb(229,231,235)' }}>
        <h3 style={{ marginBottom: 8 }}>Tracking libre</h3>
        <TrackingTimer />
      </div>
    </>;
  } else {
    body = selectedR
      ? <RutaDetail ruta={selectedR} onBack={() => setSelectedR(null)} />
      : <RutasList rutas={rutas} onSelect={setSelectedR} />;
  }

  return (
    <Phone>
      <AppHeader />
      <div className="scroll">{body}</div>
      <TabBar active={tab} onChange={(id) => { setTab(id); setFormOpen(false); setEditingS(null); setTrackingSel(null); setSelectedR(null); }} />
    </Phone>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
