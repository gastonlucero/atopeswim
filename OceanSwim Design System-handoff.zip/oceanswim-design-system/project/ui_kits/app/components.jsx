/* OceanSwim primitives — buttons, inputs, cards, header, tab bar, icons */
const { useState, useEffect, useRef } = React;

// ---------- Feather-style icons (matches react-icons/fi) ------------------
const IconUsers = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);
const IconActivity = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
  </svg>
);
const IconMap = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
    <line x1="8" y1="2" x2="8" y2="18"/>
    <line x1="16" y1="6" x2="16" y2="22"/>
  </svg>
);

// ---------- Header ---------------------------------------------------------
function AppHeader() {
  return (
    <header className="app-header">
      <h1>🌊 OceanSwim</h1>
      <div className="tagline">Coordina tus nadas en el océano</div>
    </header>
  );
}

// ---------- Tab bar --------------------------------------------------------
function TabBar({ active, onChange }) {
  const tabs = [
    { id: 'salidas',  label: 'Salidas',  Icon: IconUsers },
    { id: 'tracking', label: 'Tracking', Icon: IconActivity },
    { id: 'rutas',    label: 'Rutas',    Icon: IconMap },
  ];
  return (
    <nav className="tabbar">
      {tabs.map(t => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={`tab-button ${active === t.id ? 'active' : ''}`}
          aria-label={t.label}
        >
          <t.Icon />
          <span>{t.label}</span>
        </button>
      ))}
    </nav>
  );
}

// ---------- Field ----------------------------------------------------------
function Field({ label, error, children }) {
  return (
    <div>
      <label className="field-label">{label}</label>
      {children}
      {error ? <div className="error-message">{error}</div> : null}
    </div>
  );
}

// ---------- Card -----------------------------------------------------------
function Card({ children, onClick, className = '' }) {
  const cls = `card ${onClick ? 'clickable' : ''} ${className}`.trim();
  if (onClick) {
    return <button className={cls} onClick={onClick} style={{ textAlign: 'left', width: '100%', border: '1px solid rgb(224,247,255)', font: 'inherit', color: 'inherit', cursor: 'pointer' }}>{children}</button>;
  }
  return <div className={cls}>{children}</div>;
}

// ---------- Button ---------------------------------------------------------
function Button({ variant = 'primary', children, ...rest }) {
  return <button className={`btn-${variant}`} {...rest}>{children}</button>;
}

// ---------- Phone frame ----------------------------------------------------
function Phone({ children }) {
  return (
    <div className="phone-frame">
      <div className="phone-content">{children}</div>
    </div>
  );
}

// ---------- Constants from the codebase -----------------------------------
const ORGANIZERS = ['Pau','Enric','Xènia','Flor','Berta','Nuria','Marc','Jordi','Vladi','Ona','Xabi','Gastón','Pía','Celia'];
const LOCATIONS = [
  { id: 'barceloneta',    name: 'Espai de Mar, Barceloneta', lat: 41.3803, lon: 2.1897 },
  { id: 'sant-sebastia',  name: 'Sant Sebastià, Barcelona',  lat: 41.3839, lon: 2.1879 },
  { id: 'bogatell',       name: 'Bogatell, Barcelona',       lat: 41.3934, lon: 2.1931 },
];

const SEED_SALIDAS = [
  { id: 's1', organizerName: 'Pau',   dateTime: '2026-05-07T07:30', distanceKm: 2.5, location: { ...LOCATIONS[2], description: LOCATIONS[2].name }, participants: ['Pau','Enric','Xènia'], status: 'pending' },
  { id: 's2', organizerName: 'Berta', dateTime: '2026-05-09T08:00', distanceKm: 1.8, location: { ...LOCATIONS[1], description: LOCATIONS[1].name }, participants: ['Berta','Marc','Ona','Vladi'], status: 'pending' },
  { id: 's3', organizerName: 'Nuria', dateTime: '2026-05-11T07:00', distanceKm: 3.2, location: { ...LOCATIONS[0], description: LOCATIONS[0].name }, participants: ['Nuria','Jordi','Flor'], status: 'pending' },
];
const SEED_RUTAS = [
  { id: 'r1', name: 'Pau - Bogatell',                    salidaDate: '2026-04-25T07:30', distanceKm: 2.45 },
  { id: 'r2', name: 'Travesía Sant Sebastià → Barceloneta', salidaDate: '2026-04-18T08:00', distanceKm: 3.10 },
  { id: 'r3', name: 'Berta - Barceloneta',               salidaDate: '2026-04-11T07:00', distanceKm: 1.80 },
];

function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('es-ES', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
}
function fmtTime(iso) {
  const d = new Date(iso);
  return d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
}
function fmtDateTime(iso) { return `${fmtDate(iso)} ${fmtTime(iso)}`; }
function fmtDistance(km) { return `${km.toFixed(2)} km`; }
function fmtDuration(s) {
  const m = Math.floor(s / 60), r = s % 60;
  return `${String(m).padStart(2,'0')}:${String(r).padStart(2,'0')}`;
}

Object.assign(window, {
  IconUsers, IconActivity, IconMap,
  AppHeader, TabBar, Field, Card, Button, Phone,
  ORGANIZERS, LOCATIONS, SEED_SALIDAS, SEED_RUTAS,
  fmtDate, fmtTime, fmtDateTime, fmtDistance, fmtDuration,
});
