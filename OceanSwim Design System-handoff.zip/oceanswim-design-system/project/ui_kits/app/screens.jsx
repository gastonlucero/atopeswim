/* OceanSwim screens — Salidas (list/form), Tracking, Rutas (list/detail) */
const { useState: useStateS, useEffect: useEffectS } = React;

// =============================================================
// SALIDAS — list
// =============================================================
function SalidaListItem({ salida, onEdit, onDelete }) {
  return (
    <Card>
      <h3 className="bold" style={{ fontSize: 18, color: 'rgb(15,63,88)' }}>{salida.organizerName}</h3>
      <p className="text-sm muted">{fmtDateTime(salida.dateTime)}</p>
      <p className="text-sm muted">Distancia: {fmtDistance(salida.distanceKm)}</p>
      <p className="text-sm muted">Punto de encuentro: {salida.location.description}</p>
      {salida.participants?.length > 0 && (
        <p className="parts-line">👥 {salida.participants.join(', ')}</p>
      )}
      <div className="row-gap-2" style={{ marginTop: 12 }}>
        <Button variant="secondary">📍 Mapa</Button>
        <Button variant="primary" onClick={() => onEdit(salida)}>✏️ Editar</Button>
        <Button variant="danger" onClick={() => onDelete(salida.id)} style={{ flex: '0 0 auto', padding: '8px 12px' }}>🗑️</Button>
      </div>
    </Card>
  );
}

function SalidasList({ salidas, onNew, onEdit, onDelete }) {
  return (
    <>
      {salidas.length === 0
        ? <div className="empty">No hay salidas planificadas</div>
        : <div className="stack">{salidas.map(s => <SalidaListItem key={s.id} salida={s} onEdit={onEdit} onDelete={onDelete}/>)}</div>}
      <Button variant="primary" className="w-full" onClick={onNew} style={{ width: '100%', marginTop: 16 }}>+ Nueva Salida</Button>
    </>
  );
}

// =============================================================
// SALIDAS — form
// =============================================================
function SalidaForm({ editing, onSave, onCancel }) {
  const [organizer, setOrganizer] = useStateS(editing?.organizerName || '');
  const [dateTime, setDateTime]   = useStateS(editing?.dateTime || '');
  const [distance, setDistance]   = useStateS(editing?.distanceKm?.toString() || '');
  const [locId, setLocId]         = useStateS(editing ? (LOCATIONS.find(l => l.id === editing.location.id)?.id || '') : '');
  const [participants, setParts]  = useStateS(editing?.participants || []);
  const [errors, setErrors]       = useStateS({});

  const toggleP = (n) => setParts(prev => prev.includes(n) ? prev.filter(p => p !== n) : [...prev, n]);

  const submit = (e) => {
    e.preventDefault();
    const errs = {};
    if (!organizer) errs.organizer = 'El nombre del organizador es requerido';
    if (!dateTime)  errs.dateTime  = 'La fecha y hora son requeridas';
    if (!distance || parseFloat(distance) <= 0) errs.distance = 'La distancia debe ser mayor a 0';
    if (!locId)     errs.location  = 'La descripción del punto de encuentro es requerida';
    if (Object.keys(errs).length) { setErrors(errs); return; }
    const loc = LOCATIONS.find(l => l.id === locId);
    onSave({
      id: editing?.id || Date.now().toString(),
      organizerName: organizer,
      dateTime, distanceKm: parseFloat(distance),
      location: { ...loc, description: loc.name },
      participants,
      status: 'pending',
    });
  };

  return (
    <form onSubmit={submit} className="stack">
      <h2>{editing ? 'Editar Salida' : 'Nueva Salida'}</h2>
      <Field label="Nombre del organizador" error={errors.organizer}>
        <select className="input-field" value={organizer} onChange={e => setOrganizer(e.target.value)}>
          <option value="">Selecciona un organizador</option>
          {ORGANIZERS.map(n => <option key={n} value={n}>{n}</option>)}
        </select>
      </Field>
      <Field label="Fecha y hora" error={errors.dateTime}>
        <input type="datetime-local" className="input-field" value={dateTime} onChange={e => setDateTime(e.target.value)} />
      </Field>
      <Field label="Distancia (km)" error={errors.distance}>
        <input type="number" className="input-field" placeholder="0.0" step="0.1" min="0" value={distance} onChange={e => setDistance(e.target.value)} />
      </Field>
      <Field label="Punto de encuentro" error={errors.location}>
        <select className="input-field" value={locId} onChange={e => setLocId(e.target.value)}>
          <option value="">Selecciona una playa</option>
          {LOCATIONS.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </Field>
      <div>
        <label className="field-label">Participantes</label>
        <div className="checkbox-list">
          {ORGANIZERS.map(n => (
            <label key={n}><input type="checkbox" checked={participants.includes(n)} onChange={() => toggleP(n)} /><span>{n}</span></label>
          ))}
        </div>
        {participants.length > 0 && (
          <div className="text-sm muted" style={{ marginTop: 6 }}>
            {participants.length} participante{participants.length !== 1 ? 's' : ''} seleccionado{participants.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>
      <div className="row-gap-2">
        <Button variant="primary" type="submit">{editing ? 'Actualizar Salida' : 'Crear Salida'}</Button>
        <Button variant="secondary" type="button" onClick={onCancel}>Cancelar</Button>
      </div>
    </form>
  );
}

// =============================================================
// TRACKING — selector + recorder
// =============================================================
function TrackingSelector({ pending, onSelect }) {
  if (pending.length === 0) {
    return (
      <div className="empty">
        <p style={{ marginBottom: 8 }}>No hay salidas pendientes</p>
        <p className="text-xs" style={{ color: 'rgb(156,163,175)' }}>Crea una salida primero en la pestaña «Salidas»</p>
      </div>
    );
  }
  return (
    <div className="stack">
      <h2>Selecciona una Salida</h2>
      {pending.map(s => (
        <Card key={s.id} onClick={() => onSelect(s)}>
          <h3 className="bold" style={{ fontSize: 18, color: 'rgb(15,63,88)' }}>{s.organizerName}</h3>
          <p className="text-sm muted">{fmtDateTime(s.dateTime)}</p>
          <p className="text-sm muted">Lugar: {s.location.description}</p>
          <p className="text-sm" style={{ color: 'rgb(37,99,235)', fontWeight: 500, marginTop: 6 }}>
            Distancia planeada: {fmtDistance(s.distanceKm)}
          </p>
        </Card>
      ))}
    </div>
  );
}

function TrackingForm({ salida, onFinish, onBack }) {
  const [distance, setDistance] = useStateS('');
  const [error, setError]       = useStateS('');
  const [done, setDone]         = useStateS(false);

  const submit = (e) => {
    e.preventDefault();
    const v = parseFloat(distance);
    if (!v || v < 0.1) { setError('La distancia registrada debe ser mayor a 0.1 km'); return; }
    setDone(true);
    setTimeout(() => onFinish(salida, v), 1400);
  };

  if (done) {
    return (
      <div style={{ paddingTop: 24 }}>
        <div className="success-soft">
          <div className="big">✅ Salida finalizada</div>
          <div className="text-sm" style={{ marginTop: 4 }}>La ruta ha sido guardada</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <span className="back-link" onClick={onBack}>← Volver</span>
      <Card className="" >
        <h2 style={{ fontSize: 20 }}>{salida.organizerName}</h2>
        <p className="text-sm muted">{fmtDateTime(salida.dateTime)}</p>
        <p className="text-sm muted" style={{ marginTop: 6 }}>📍 {salida.location.description}</p>
        <p className="text-sm muted">Distancia planeada: {fmtDistance(salida.distanceKm)}</p>
      </Card>
      <form onSubmit={submit} className="stack" style={{ marginTop: 16 }}>
        <h3>Registrar Distancia Completada</h3>
        <Field label="Distancia completada (km)" error={error}>
          <input type="number" className="input-field" placeholder="0.0" step="0.1" min="0" value={distance} onChange={e => setDistance(e.target.value)} />
        </Field>
        <Button variant="primary" type="submit">Finalizar Salida</Button>
      </form>
    </div>
  );
}

function TrackingTimer() {
  const [status, setStatus] = useStateS('idle');
  const [secs, setSecs]     = useStateS(0);
  useEffectS(() => {
    if (status !== 'recording') return;
    const id = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [status]);

  if (status === 'idle') {
    return (
      <div style={{ paddingTop: 32 }}>
        <div className="timer-big">{fmtDuration(secs)}</div>
        <div className="timer-cap">Pulsa iniciar cuando empieces a nadar</div>
        <Button variant="primary" onClick={() => { setSecs(0); setStatus('recording'); }} style={{ width: '100%', marginTop: 24 }}>Iniciar Tracking</Button>
      </div>
    );
  }
  if (status === 'recording') {
    return (
      <div style={{ paddingTop: 32 }}>
        <div className="timer-big recording">{fmtDuration(secs)}</div>
        <div className="timer-cap">Nada en progreso...</div>
        <Button variant="danger" onClick={() => setStatus('finished')} style={{ width: '100%', marginTop: 24 }}>Detener</Button>
      </div>
    );
  }
  return (
    <div style={{ paddingTop: 8 }}>
      <div className="info-pill">
        <p className="text-sm muted">Tiempo registrado</p>
        <div style={{ fontSize: 36, fontWeight: 700, color: 'rgb(2,132,199)' }}>{fmtDuration(secs)}</div>
      </div>
      <Button variant="secondary" onClick={() => { setSecs(0); setStatus('idle'); }} style={{ width: '100%', marginTop: 12 }}>Nuevo Tracking</Button>
    </div>
  );
}

// =============================================================
// RUTAS
// =============================================================
function RutaListItem({ ruta, onSelect }) {
  return (
    <Card onClick={() => onSelect(ruta)}>
      <h3 className="bold" style={{ fontSize: 18, color: 'rgb(15,63,88)' }}>{ruta.name}</h3>
      <p className="text-sm muted">{fmtDate(ruta.salidaDate)}</p>
      <div className="text-sm muted" style={{ marginTop: 6 }}>📏 {fmtDistance(ruta.distanceKm)}</div>
    </Card>
  );
}

function RutasList({ rutas, onSelect }) {
  if (rutas.length === 0) return <div className="empty">No hay rutas registradas</div>;
  return <div className="stack">{rutas.map(r => <RutaListItem key={r.id} ruta={r} onSelect={onSelect}/>)}</div>;
}

function RutaDetail({ ruta, onBack }) {
  return (
    <div>
      <span className="back-link" onClick={onBack}>← Volver</span>
      <Card>
        <h2 style={{ fontSize: 22 }}>{ruta.name}</h2>
        <div className="row-gap-2" style={{ marginTop: 14 }}>
          <Button variant="primary">✏️ Editar nombre</Button>
          <Button variant="danger">🗑️ Eliminar</Button>
        </div>
      </Card>
      <Card className="" >
        <p className="text-sm muted">Fecha de la salida</p>
        <p style={{ fontSize: 20, fontWeight: 700, color: 'rgb(2,132,199)' }}>{fmtDate(ruta.salidaDate)}</p>
        <p className="text-sm muted" style={{ marginTop: 12 }}>Distancia completada</p>
        <p style={{ fontSize: 20, fontWeight: 700, color: 'rgb(2,132,199)' }}>{fmtDistance(ruta.distanceKm)}</p>
      </Card>
      <div style={{ marginTop: 14, background: 'rgb(243,244,246)', padding: 18, borderRadius: 8, textAlign: 'center', color: 'rgb(107,114,128)' }}>
        No hay datos de GPS para mostrar en el mapa
      </div>
    </div>
  );
}

Object.assign(window, {
  SalidasList, SalidaForm, TrackingSelector, TrackingForm, TrackingTimer,
  RutasList, RutaDetail,
});
