/* OceanSwim Redesign — single-screen sporty oceanic phone prototype.
   One file, no internal navigation between "tabs": Hoy is the home,
   Tracking takes over the screen when active, history is a peek below.
   New-swim is a bottom sheet with smart defaults (3 taps to commit). */

const { useState, useEffect, useMemo, useRef } = React;

const CREW = ['Pau','Enric','Xènia','Flor','Berta','Nuria','Marc','Jordi','Vladi','Ona'];
const BEACHES = [
  { id: 'bog', name: 'Bogatell' },
  { id: 'bcn', name: 'Barceloneta' },
  { id: 'sse', name: 'Sant Sebastià' },
];
const TIMES = ['06:30','07:00','07:30','08:00'];

const NEXT = {
  organizer: 'Pau',
  isYou: false,
  weekday: 'JUEVES',
  in_h: 12, in_m: 24,
  date: 'Mañana · 07:30',
  beach: 'Bogatell',
  km: 2.5,
  pace: '02:18 / 100m',
  water: '17°',
  crew: ['Pau','Enric','Xènia'],
  crewMore: 0,
};

const UPCOMING = [
  { d: 'SAB', day: 9, t: '08:00', name: 'Sant Sebastià', km: 1.8, who: 'Berta · 4', dist: '1.8 km' },
  { d: 'LUN', day: 11, t: '07:00', name: 'Barceloneta',  km: 3.2, who: 'Nuria · 3', dist: '3.2 km' },
];

const HISTORY = [
  { name: 'Pau · Bogatell',                  date: 'Sab 25 abr',  km: 2.45 },
  { name: 'Travesía Sant Seb → Barceloneta', date: 'Sab 18 abr',  km: 3.10 },
  { name: 'Berta · Barceloneta',             date: 'Sab 11 abr',  km: 1.80 },
];

// ────────────────────────────────────────────────────────────────────
// Sparkline
// ────────────────────────────────────────────────────────────────────
function Spark({ values, color }) {
  const w = 64, h = 18;
  const max = Math.max(...values), min = Math.min(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ────────────────────────────────────────────────────────────────────
// Top bar
// ────────────────────────────────────────────────────────────────────
function TopBar() {
  return (
    <div className="os-top">
      <div className="brand">
        <div className="mark">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <path d="M2 12c2-3 4-3 6 0s4 3 6 0 4-3 6 0" stroke="white"/>
            <path d="M2 17c2-3 4-3 6 0s4 3 6 0 4-3 6 0" stroke="white" opacity=".5"/>
          </svg>
        </div>
        OceanSwim
      </div>
      <div className="avatar">PA</div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────
// HERO — next swim card
// ────────────────────────────────────────────────────────────────────
function Hero({ featured = true, onStart }) {
  return (
    <div className={`hero ${featured ? 'feat' : ''}`}>
      <div className="label">Próxima salida · en {NEXT.in_h}h</div>
      <div className="when">
        <div className="when-num">{NEXT.in_h}</div>
        <div className="when-unit">horas</div>
      </div>
      <div className="place">{NEXT.beach.toUpperCase()} · {NEXT.km} KM</div>
      <div className="meta">
        <span><b>{NEXT.pace}</b> ritmo objetivo</span>
        <span><b>{NEXT.water}</b> agua</span>
      </div>
      <div className="crew">
        <div className="stack">
          {NEXT.crew.map((n,i) => (
            <div className="av" key={n}>{n.slice(0,1)}</div>
          ))}
        </div>
        <div className="more">
          {NEXT.crew.join(', ')} {NEXT.crewMore > 0 && `+${NEXT.crewMore}`}
        </div>
      </div>
      <div className="actions">
        <button className="start-btn" onClick={onStart}>
          ▶ Empezar a nadar
        </button>
        <button className="ghost-btn">Mapa</button>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────
// HOME — single screen
// ────────────────────────────────────────────────────────────────────
function Home({ onStart, onNew }) {
  return (
    <>
      <TopBar/>
      <div className="os-scroll">
        <Hero onStart={onStart}/>

        <div className="os-section"><h2>Esta semana</h2><span className="more">Mes ›</span></div>
        <div className="stats">
          <div className="stat">
            <div className="v">12.4<small>km</small></div>
            <div className="l">Distancia</div>
            <div className="spark"><Spark values={[1,2,1.5,3,2.2,3.4,2.5]} color="var(--accent)"/></div>
          </div>
          <div className="stat">
            <div className="v">3</div>
            <div className="l">Salidas</div>
            <div className="spark"><Spark values={[2,1,2,3,2,3,3]} color="var(--accent-2)"/></div>
          </div>
          <div className="stat">
            <div className="v">02:14<small>/100</small></div>
            <div className="l">Ritmo</div>
            <div className="spark"><Spark values={[2.4,2.3,2.35,2.25,2.2,2.18,2.14]} color="var(--good)"/></div>
          </div>
        </div>

        <div className="os-section"><h2>Próximas</h2><span className="more">Todas ›</span></div>
        <div className="os-list">
          {UPCOMING.map((s,i) => (
            <div className="swim-card" key={i}>
              <div className="date-block">
                <div className="d">{s.day}</div>
                <div className="m">{s.d}</div>
              </div>
              <div className="body">
                <div className="t">{s.name}</div>
                <div className="s">{s.t} · {s.who}</div>
              </div>
              <div className="right">
                <div className="km">{s.km}<small>km</small></div>
                <div className="time">{s.t}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="os-section"><h2>Historial</h2><span className="more">Ver todo ›</span></div>
        <div className="os-list">
          {HISTORY.map((r,i) => (
            <div className="history-row" key={i}>
              <div>
                <div className="name">{r.name}</div>
                <div className="date">{r.date}</div>
              </div>
              <div className="km">{r.km.toFixed(2)}<small>km</small></div>
            </div>
          ))}
        </div>

        <div style={{ height: 100 }}/>
      </div>
      <button className="fab" onClick={onNew}>+ Crear salida</button>
    </>
  );
}

// ────────────────────────────────────────────────────────────────────
// TRACKING screen
// ────────────────────────────────────────────────────────────────────
function fmt(s) {
  const m = Math.floor(s/60), r = s%60;
  return `${String(m).padStart(2,'0')}:${String(r).padStart(2,'0')}`;
}
function Tracking({ onStop }) {
  const [s, setS] = useState(847); // 14:07
  useEffect(() => {
    const id = setInterval(() => setS(x => x+1), 1000);
    return () => clearInterval(id);
  }, []);
  const km = (s * 0.00072).toFixed(2);
  return (
    <>
      <TopBar/>
      <div className="track">
        <div className="where">
          <div className="place">Bogatell</div>
          <div className="live"><span className="dot"/>EN VIVO</div>
        </div>
        <div className="timer">
          <div className="num">{fmt(s)}</div>
          <div className="lbl">Tiempo en agua</div>
        </div>
        <div className="telem">
          <div className="cell">
            <div className="v">{km}<small>km</small></div>
            <div className="l">Distancia</div>
          </div>
          <div className="cell">
            <div className="v">02:21<small>/100</small></div>
            <div className="l">Ritmo</div>
          </div>
          <div className="cell">
            <div className="v">17<small>°C</small></div>
            <div className="l">Agua</div>
          </div>
        </div>
        <button className="stop" onClick={onStop}>■ Detener</button>
      </div>
    </>
  );
}

// ────────────────────────────────────────────────────────────────────
// NEW SWIM — bottom sheet
// ────────────────────────────────────────────────────────────────────
function NewSheet({ onClose, onCreate }) {
  const [beach, setBeach] = useState('bog');
  const [time, setTime] = useState('07:30');
  const [km, setKm] = useState(2.5);
  const [crew, setCrew] = useState(['Pau','Enric']);

  const toggle = (n) => setCrew(c => c.includes(n) ? c.filter(x => x !== n) : [...c, n]);

  return (
    <div className="sheet-mask" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="grip"/>
        <h3>Nueva salida</h3>

        <div className="step-l">¿Dónde?</div>
        <div className="chip-row">
          {BEACHES.map(b => (
            <div key={b.id} className={`chip ${beach===b.id?'on':''}`} onClick={() => setBeach(b.id)}>
              {b.name}
            </div>
          ))}
        </div>

        <div className="step-l">¿Cuándo?</div>
        <div className="chip-row" style={{ marginBottom: 8 }}>
          <div className="chip on">Mañana</div>
          <div className="chip">Sábado</div>
          <div className="chip">Domingo</div>
          <div className="chip">Otro día</div>
        </div>
        <div className="time-pick">
          {TIMES.map(t => (
            <div key={t} className={`chip ${time===t?'on':''}`} onClick={() => setTime(t)}>{t}</div>
          ))}
        </div>

        <div className="step-l">Distancia</div>
        <div className="dist-row">
          <button onClick={() => setKm(k => Math.max(0.5, +(k-0.5).toFixed(1)))}>−</button>
          <div className="v">{km.toFixed(1)}<small>km</small></div>
          <button onClick={() => setKm(k => +(k+0.5).toFixed(1))}>+</button>
        </div>

        <div className="step-l">Quién viene · {crew.length}</div>
        <div className="crew-grid">
          {CREW.map(n => (
            <div key={n} className={`crew-chip ${crew.includes(n)?'on':''}`} onClick={() => toggle(n)}>
              <div className="av">{n.slice(0,1)}</div>
              <div className="n">{n}</div>
            </div>
          ))}
        </div>

        <button className="commit" onClick={onCreate}>Crear salida</button>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────
// PROTOTYPE root
// ────────────────────────────────────────────────────────────────────
function Prototype({ theme }) {
  const [mode, setMode] = useState('home'); // home | track
  const [sheet, setSheet] = useState(false);
  return (
    <div className="os" data-theme={theme}>
      {mode === 'home'
        ? <Home onStart={() => setMode('track')} onNew={() => setSheet(true)}/>
        : <Tracking onStop={() => setMode('home')}/>}
      {sheet && <NewSheet onClose={() => setSheet(false)} onCreate={() => setSheet(false)}/>}
    </div>
  );
}

Object.assign(window, { Prototype, Home, Tracking, NewSheet });
